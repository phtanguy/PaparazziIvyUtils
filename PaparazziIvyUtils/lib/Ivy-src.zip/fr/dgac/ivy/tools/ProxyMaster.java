/**
 * ProxyMaster: Ivy relay, first attempt
 *
 * @author	Yannick Jestin
 * @author	<a href="http://www.tls.cena.fr/products/ivy/">http://www.tls.cena.fr/products/ivy/</a>
 *
 * (c) ENAC
 *
 * changelog:
 *   1.2.12
 */
package fr.dgac.ivy.tools ; // TODO go into sub tools, and build a shell/.BAT script
import fr.dgac.ivy.* ;
import java.io.*;
import java.net.*;
import java.util.* ;
import gnu.getopt.Getopt;
import org.apache.regexp.*;

public class ProxyMaster {

  private ServerSocket serviceSocket;
  private boolean isRunning=false;
  private static boolean debug=false;
  private boolean doRun=true; // stops running when set to false
  private Vector proxyClients = new Vector();
  private Hashtable ghostFathers = new Hashtable(); // key: ghostId value: SubReader
  private static int serial=0;

  public static int DEFAULT_SERVICE_PORT = 3456 ;
  public static final String DEFAULTNAME = "ProxyMaster";
  public static final String helpmsg = "usage: java fr.dgac.ivy.ProxyMaster [options]\n\t-p\tport number, default "+DEFAULT_SERVICE_PORT+"\n\t-q\tquiet, no tty output\n\t-d\tdebug\n\t-h\thelp\nListens on the TCP port for ProxyClients to join.\n";

  private static String name = DEFAULTNAME;
  public static void main(String[] args) {
    Ivy bus;
    Getopt opt = new Getopt("ProxyMaster",args,"dqp:h");
    int c;
    int servicePort = DEFAULT_SERVICE_PORT;
    boolean quiet = false;
    while ((c = opt.getopt()) != -1) switch (c) {
    case 'q':
      quiet=true;
      break;
    case 'd':
      Properties sysProp = System.getProperties();
      sysProp.put("IVY_DEBUG","yes");
      break;
    case 'p':
      String s="";
      try {
        servicePort = Integer.parseInt(s=opt.getOptarg());
      } catch (NumberFormatException nfe) {
        System.out.println("Invalid port number: " + s );
	System.exit(0);
      }
      break;
    case 'h':
    default:
      System.out.println(helpmsg);
      System.exit(0);
    }
    try {
      if (!quiet) System.out.println("listening on "+servicePort);
      ProxyMaster pm = new ProxyMaster(servicePort);
    } catch (IOException ioe) {
      System.out.println("error, can't set up the proxy master");
      ioe.printStackTrace();
      System.exit(-1);
    }
  }

  public ProxyMaster(int servicePort) throws IOException {
    serviceSocket = new ServerSocket(servicePort) ;
    while ( true ) {
      try {
        new SubReader(serviceSocket.accept());
      } catch( IOException e ) {
	traceDebug("TCP socket reader caught an exception " + e.getMessage());
      }
    }
  }

  class SubReader extends Thread {
    BufferedReader in;
    PrintWriter out;
    String hostname=null;	// I will know from the socket
    String busDomain=null;	// I will know it from the Hello message

    SubReader(Socket socket) throws IOException {
      proxyClients.addElement(this);
      hostname = socket.getInetAddress().getHostName();
      in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
      out=new PrintWriter(new OutputStreamWriter(socket.getOutputStream()));
      start();
    }

    public void send(String s) { // sends a message to the SubReader peer ( a ProxyClient )
      out.println(s);
      out.flush();
    }

    public void run() {
      traceDebug("Subreader Thread started");
      String msg = null;
      try {
	while (doRun) {
	  msg=in.readLine();
	  if (msg==null) break;
	  parseMsg(msg);
	}
      } catch (IOException ioe) {
	traceDebug("Subreader exception ...");
	ioe.printStackTrace();
	System.exit(0);
      }
      traceDebug("Subreader Thread stopped");
      System.out.println("ProxyClient on "+hostname+", bus "+busDomain+" disconnected");
      proxyClients.removeElement(this);
    }

    RE helloRE=new RE("^Hello bus=(.*)");
    RE getId=new RE("^GetID id=(.*)");
    RE fwdPuppet=new RE("^ForwardPuppet id=(.*) buffer=(.*)");
    RE fwdGhost=new RE("^ForwardGhost id=(.*) buffer=(.*)");

    void parseMsg(String msg) {
      // System.out.println("PM parsing "+msg);
      if (helloRE.match(msg)) {
	busDomain = helloRE.getParen(1);
	System.out.println("PC connected from "+hostname+", on the bus "+busDomain);
      } else if (getId.match(msg)) {
	// a new Ghost has appeared and requests an Id
	System.out.println("PM registering a new Ghost");
	String newGhostId = new Integer(serial++).toString();
	// I give it its ID
	send("ID id="+getId.getParen(1)+" value="+newGhostId);
	ghostFathers.put(newGhostId,this); // remember the SubReader holding this Ghost
	// I ask all other Clients to prepare a puppet
	for (Enumeration e=proxyClients.elements();e.hasMoreElements();) {
	  SubReader sr = (SubReader)e.nextElement();
	  if (sr!=SubReader.this) {
	    // System.out.println("propagate CreatePuppet to "+sr.busDomain);
	    sr.send("CreatePuppet id="+newGhostId);
	  } else {
	    // System.out.println("won't propagate CreatePuppet to "+sr.busDomain);
	  }
	}
      } else if (fwdGhost.match(msg)) {
	System.out.println("PM forwarding ["+msg+"] to its Ghost");
	SubReader sr = (SubReader) ghostFathers.get(fwdGhost.getParen(1));
	sr.send(msg);
      } else if (fwdPuppet.match(msg)) {
	System.out.println("PM forwarding ["+msg+"] to all other PCs");
	for (Enumeration e=proxyClients.elements();e.hasMoreElements();) {
	  SubReader sr = (SubReader)e.nextElement();
	  if (sr!=SubReader.this) sr.send(msg);
	}
      } else {
	System.out.println("error unknown message "+msg);
      }
    }
  } // class SubReader

  private static void traceDebug(String s){
    if (debug) System.out.println("-->ProxyMaster "+name+"<-- "+s);
  }

}
